# File generated automatically by ../interface/nsim/version.pyc
# DO NOT EDIT MANUALLY!
release_date = 'Tue Dec 13 15:08:29 2011'
version = (0, 2, 0)
dist_mode = 'all-source'
dist_date = 'Tue Dec 13 15:08:32 GMT 2011'
vcinfo = """
changeset:   458:f66c50d88636
tag:         tip
user:        Matteo Franchin
date:        Tue Dec 13 15:08:30 2011 +0000
files:       .hgtags
description:
Added tag 0.2.0 for changeset ba6aa29bb24b


"""
dist_vcinfo = """
changeset:   107:d8fd27a25817
branch:      dist
tag:         tip
user:        Matteo Franchin
date:        Mon Dec 12 20:00:33 2011 +0000
files:       patches/check-deps.sh patches/petsc/patches.sh
description:
Bugfix.


"""
