#export PYTHONPATH=$PYTHONPATH:/sw/lib/docutils #need this on fink system

#Need epydoc 3.0 for this
nsim /usr/bin/epydoc -v --config epydoc.conf
