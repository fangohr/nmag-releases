type physical_dimension = (string * int * int) array
