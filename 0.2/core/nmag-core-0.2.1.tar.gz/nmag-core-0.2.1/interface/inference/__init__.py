"""
The inference engine

Copyright |copy| 2005-2007 by University of Southampton 

:Author: T Fischbacher, G Bordignon, M Frachin, H Fangohr

:License: GNU Public License (GPL)

:Version: $Id: __init__.py 3294 2007-04-20 06:12:09Z fangohr $

"""


