"""nmag -- Multiferroic extensions
"""

__docformat__="restructuredtext"

## import all objects from main.py
from main_magnetoelectric import *

import nmeshlib as mesh
