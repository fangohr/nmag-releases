'''Constants useful in magnetism.'''

from nsim.si_units.si import *

