def test_pymodules_installed():
	#is the ply module installed (Lex and Yacc for Python)?
	import ply

	#is the pytables module installed (Python interface to hdf5)?
	import tables
