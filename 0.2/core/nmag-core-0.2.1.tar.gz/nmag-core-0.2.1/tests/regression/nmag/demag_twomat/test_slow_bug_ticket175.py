import nmag
from nsim.testtools import run_make, DirectoryOf

def test_demag():
    run_make(__file__)

if __name__ == "__main__":
    test_demag()
