import ocaml


ocaml.mpi_status()
ocaml.mpi_hello()

