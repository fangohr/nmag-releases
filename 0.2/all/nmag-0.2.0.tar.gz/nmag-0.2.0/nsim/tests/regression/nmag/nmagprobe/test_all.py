
def test_all():
  from nsim.testtools import run_make
  run_make(__file__)

if __name__ == "__main__":
  test_all()

