# File generated automatically by ../interface/nsim/version.pyc
# DO NOT EDIT MANUALLY!
release_date = 'Fri Jan 13 09:38:20 2012'
version = (0, 2, 1)
dist_mode = 'all-source'
dist_date = 'Fri Jan 13 09:38:22 GMT 2012'
vcinfo = """
changeset:   467:d7c316deb156
tag:         tip
user:        Hans Fangohr [eta] <fangohr@soton.ac.uk>
date:        Fri Jan 13 09:38:21 2012 +0000
summary:     Added tag 0.2.1 for changeset 637e66c8f302

"""
dist_vcinfo = """
changeset:   112:df0ea27ff7b2
branch:      dist
tag:         tip
user:        Matteo Franchin
date:        Fri Dec 23 13:56:21 2011 +0000
summary:     Added tag 0.2.0 for changeset 7dcb79a86a5f

"""
